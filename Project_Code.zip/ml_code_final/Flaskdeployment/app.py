from flask import Flask,request, url_for, redirect, render_template
import pickle
import numpy as np

model = pickle.load(open('catboost_model.pkl','rb'))
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('home.html')

@app.route('/predict', methods=['POST'])
def home():
    data1 = request.form['a']
    data2 = request.form['b']
    data3 = request.form['c']
    data4 = request.form['e']
    data5 = request.form['f']

    l = [1,0,2,2,1,0,0,2,7,21,int(data1),3.526361,2.890372,0,1,2,0,0,int(data5),int(data4),0,2.302585,0,4.143135,int(data3),int(data2)]
    final = [np.array(l)]
    result = model.predict(final)
    if result[0] == 0:
        result = 'This booking more likely to be cancelled by the guest.'
    elif result[0] == 1:
        result = 'This booking has less chances to be cancelled by the guest.'
    
    return render_template('home.html', result=result)


if __name__ == "__main__":
    app.run(host='0.0.0.0',port=8080)